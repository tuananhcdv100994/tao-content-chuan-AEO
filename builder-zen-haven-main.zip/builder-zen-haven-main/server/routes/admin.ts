import { RequestHandler } from "express";
import { AdminStats, AdminUserAction } from "@shared/api";
import { z } from "zod";
import { validateToken, users } from "./auth";
import { upgradeRequests } from "./upgrade";

const userActionSchema = z.object({
  userId: z.string(),
  action: z.enum(["upgrade", "downgrade", "delete", "reset-usage"]),
});

// Get all users (admin only)
export const handleGetAllUsers: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    // Return all users except sensitive data
    const safeUsers = users.map((user) => ({
      id: user.id,
      username: user.username,
      email: user.email,
      name: user.name,
      phone: user.phone,
      role: user.role,
      plan: user.plan,
      usageCount: user.usageCount,
      maxUsage: user.maxUsage,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
    }));

    res.json({
      success: true,
      data: safeUsers,
    });
  } catch (error) {
    console.error("Get all users error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching users",
    });
  }
};

// Get admin statistics
export const handleGetAdminStats: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    // Calculate statistics
    const totalUsers = users.filter((u) => u.role !== "admin").length;
    const freeUsers = users.filter(
      (u) => u.role !== "admin" && u.plan === "free",
    ).length;
    const premiumUsers = users.filter(
      (u) => u.role !== "admin" && u.plan === "premium",
    ).length;
    const totalGenerations = users
      .filter((u) => u.role !== "admin")
      .reduce((sum, user) => sum + user.usageCount, 0);

    // Generate mock daily/monthly/yearly data for now
    const currentDate = new Date();
    const dailyUsage = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(currentDate.getDate() - i);
      return {
        date: date.toISOString().split("T")[0],
        count: Math.floor(Math.random() * 50) + 10,
      };
    }).reverse();

    const monthlyUsage = Array.from({ length: 6 }, (_, i) => {
      const date = new Date();
      date.setMonth(currentDate.getMonth() - i);
      return {
        month: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`,
        count: Math.floor(Math.random() * 500) + 100,
      };
    }).reverse();

    const yearlyUsage = Array.from({ length: 3 }, (_, i) => {
      const year = currentDate.getFullYear() - i;
      return {
        year: year.toString(),
        count: Math.floor(Math.random() * 5000) + 1000,
      };
    }).reverse();

    const stats: AdminStats = {
      totalUsers,
      freeUsers,
      premiumUsers,
      totalGenerations,
      dailyUsage,
      monthlyUsage,
      yearlyUsage,
    };

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    console.error("Get admin stats error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching statistics",
    });
  }
};

// Perform user actions (admin only)
export const handleUserAction: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    const { userId: targetUserId, action } = userActionSchema.parse(req.body);

    // Find target user
    const userIndex = users.findIndex((u) => u.id === targetUserId);
    if (userIndex === -1) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const targetUser = users[userIndex];

    // Prevent admin from acting on other admins
    if (targetUser.role === "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Cannot modify admin accounts" });
    }

    // Perform the action
    switch (action) {
      case "upgrade":
        users[userIndex] = {
          ...targetUser,
          plan: "premium",
          maxUsage: 200,
          usageCount: 0, // Reset usage for new plan
        };
        break;

      case "downgrade":
        users[userIndex] = {
          ...targetUser,
          plan: "free",
          maxUsage: 10,
          usageCount: Math.min(targetUser.usageCount, 10), // Cap usage to free limit
        };
        break;

      case "delete":
        users.splice(userIndex, 1);
        return res.json({
          success: true,
          message: "User deleted successfully",
        });

      case "reset-usage":
        users[userIndex] = {
          ...targetUser,
          usageCount: 0,
        };
        break;

      default:
        return res
          .status(400)
          .json({ success: false, message: "Invalid action" });
    }

    res.json({
      success: true,
      message: `User ${action} completed successfully`,
      user: users[userIndex],
    });
  } catch (error) {
    console.error("User action error:", error);

    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: "Invalid request data",
      });
    }

    res.status(500).json({
      success: false,
      message: "Error performing user action",
    });
  }
};

// Get system information (admin only)
export const handleGetSystemInfo: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    const systemInfo = {
      totalUsers: users.filter((u) => u.role !== "admin").length,
      totalAdmins: users.filter((u) => u.role === "admin").length,
      pendingUpgrades: upgradeRequests.length,
      serverUptime: process.uptime(),
      memoryUsage: process.memoryUsage(),
      nodeVersion: process.version,
      timestamp: new Date().toISOString(),
    };

    res.json({
      success: true,
      data: systemInfo,
    });
  } catch (error) {
    console.error("Get system info error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching system information",
    });
  }
};
