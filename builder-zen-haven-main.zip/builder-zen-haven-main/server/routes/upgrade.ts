import { RequestHandler } from "express";
import { UpgradeRequest, UpgradeResponse } from "@shared/api";
import { z } from "zod";
import { validateToken, users } from "./auth";

const upgradeSchema = z.object({
  userId: z.string(),
  name: z.string().min(1).max(50),
  phone: z.string().min(10).max(15),
  email: z.string().email(),
  plan: z.literal("premium"),
});

// In-memory storage for upgrade requests (in production, use database)
let upgradeRequests: (UpgradeRequest & { id: string; createdAt: string })[] =
  [];
let requestIdCounter = 1;

export const handleUpgrade: RequestHandler = async (req, res) => {
  try {
    // Validate authentication
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    // Find user
    const user = users.find((u) => u.id === userId);
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    // Check if user is already premium
    if (user.plan === "premium") {
      const response: UpgradeResponse = {
        success: false,
        message: "Bạn đã là thành viên Premium",
      };
      return res.status(400).json(response);
    }

    // Validate request data
    const upgradeData = upgradeSchema.parse(req.body);

    // Create upgrade request
    const upgradeRequest = {
      id: `upgrade_${requestIdCounter++}`,
      ...upgradeData,
      createdAt: new Date().toISOString(),
    };

    upgradeRequests.push(upgradeRequest);

    const response: UpgradeResponse = {
      success: true,
      message: "Yêu cầu nâng cấp đã được gửi thành công",
      paymentInfo: {
        amount: 299000,
        currency: "VND",
        contact: "Zalo: 0792762794",
      },
    };

    res.json(response);
  } catch (error) {
    console.error("Upgrade request error:", error);

    if (error instanceof z.ZodError) {
      const response: UpgradeResponse = {
        success: false,
        message: "Thông tin không hợp lệ",
      };
      return res.status(400).json(response);
    }

    const response: UpgradeResponse = {
      success: false,
      message: "Có lỗi xảy ra khi xử lý yêu cầu nâng cấp",
    };

    res.status(500).json(response);
  }
};

// Admin function to approve upgrade (simulate payment completion)
export const handleApproveUpgrade: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    const { upgradeRequestId } = req.body;

    // Find upgrade request
    const upgradeRequest = upgradeRequests.find(
      (req) => req.id === upgradeRequestId,
    );
    if (!upgradeRequest) {
      return res
        .status(404)
        .json({ success: false, message: "Upgrade request not found" });
    }

    // Find and upgrade user
    const userIndex = users.findIndex((u) => u.id === upgradeRequest.userId);
    if (userIndex === -1) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    // Upgrade user to premium
    users[userIndex] = {
      ...users[userIndex],
      plan: "premium",
      maxUsage: 200,
      usageCount: 0, // Reset usage count for new period
    };

    // Remove upgrade request
    upgradeRequests = upgradeRequests.filter(
      (req) => req.id !== upgradeRequestId,
    );

    res.json({
      success: true,
      message: "User upgraded to premium successfully",
      user: users[userIndex],
    });
  } catch (error) {
    console.error("Approve upgrade error:", error);
    res.status(500).json({
      success: false,
      message: "Error approving upgrade",
    });
  }
};

// Get all upgrade requests (admin only)
export const handleGetUpgradeRequests: RequestHandler = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const adminUser = users.find((u) => u.id === userId);
    if (!adminUser || adminUser.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Admin access required" });
    }

    res.json({
      success: true,
      data: upgradeRequests,
    });
  } catch (error) {
    console.error("Get upgrade requests error:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching upgrade requests",
    });
  }
};

export { upgradeRequests };
