import { RequestHandler } from "express";
import { AuthResponse, LoginRequest, RegisterRequest, User } from "@shared/api";
import { z } from "zod";

// In-memory storage for demo. In production, use a proper database.
let users: User[] = [
  {
    id: "admin",
    username: "Tuananhcdv",
    email: "admin@plugai.top",
    name: "Admin",
    phone: "0792762794",
    role: "admin",
    plan: "premium",
    usageCount: 0,
    maxUsage: 999999,
    createdAt: new Date().toISOString(),
  },
];

let userIdCounter = 1;

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

const registerSchema = z.object({
  username: z.string().min(3).max(20),
  email: z.string().email(),
  name: z.string().min(1).max(50),
  phone: z.string().min(10).max(15),
  password: z.string().min(6),
});

// Simple JWT-like token generation (in production, use proper JWT)
const generateToken = (userId: string): string => {
  return Buffer.from(`${userId}:${Date.now()}`).toString("base64");
};

const validateToken = (token: string): string | null => {
  try {
    const decoded = Buffer.from(token, "base64").toString();
    const [userId] = decoded.split(":");
    return userId;
  } catch {
    return null;
  }
};

export const handleLogin: RequestHandler = (req, res) => {
  try {
    const { username, password } = loginSchema.parse(req.body);

    // Check credentials
    const user = users.find((u) => u.username === username);

    // Admin credentials
    if (username === "Tuananhcdv" && password === "Tuananh1994@") {
      const adminUser = users.find((u) => u.role === "admin");
      if (adminUser) {
        const token = generateToken(adminUser.id);
        const response: AuthResponse = {
          success: true,
          user: { ...adminUser, lastLogin: new Date().toISOString() },
          token,
        };
        return res.json(response);
      }
    }

    // Regular user login (simplified - in production, hash passwords)
    if (user && password.length >= 6) {
      const token = generateToken(user.id);
      const updatedUser = { ...user, lastLogin: new Date().toISOString() };

      // Update user in storage
      const userIndex = users.findIndex((u) => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
      }

      const response: AuthResponse = {
        success: true,
        user: updatedUser,
        token,
      };
      return res.json(response);
    }

    const response: AuthResponse = {
      success: false,
      message: "Tên đăng nhập hoặc mật khẩu không đúng",
    };
    res.status(401).json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: AuthResponse = {
        success: false,
        message: "Thông tin đăng nhập không hợp lệ",
      };
      return res.status(400).json(response);
    }

    const response: AuthResponse = {
      success: false,
      message: "Lỗi server",
    };
    res.status(500).json(response);
  }
};

export const handleRegister: RequestHandler = (req, res) => {
  try {
    const userData = registerSchema.parse(req.body);

    // Check if username or email already exists
    const existingUser = users.find(
      (u) => u.username === userData.username || u.email === userData.email,
    );

    if (existingUser) {
      const response: AuthResponse = {
        success: false,
        message: "Tên đăng nhập hoặc email đã tồn tại",
      };
      return res.status(409).json(response);
    }

    // Create new user
    const newUser: User = {
      id: `user_${userIdCounter++}`,
      username: userData.username,
      email: userData.email,
      name: userData.name,
      phone: userData.phone,
      role: "user",
      plan: "free",
      usageCount: 0,
      maxUsage: 10, // Free users get 10 generations
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);

    const token = generateToken(newUser.id);
    const response: AuthResponse = {
      success: true,
      user: newUser,
      token,
    };

    res.status(201).json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: AuthResponse = {
        success: false,
        message: "Thông tin đăng ký không hợp lệ",
      };
      return res.status(400).json(response);
    }

    const response: AuthResponse = {
      success: false,
      message: "Lỗi server",
    };
    res.status(500).json(response);
  }
};

export const handleGetProfile: RequestHandler = (req, res) => {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) {
    return res.status(401).json({ success: false, message: "Token required" });
  }

  const userId = validateToken(token);
  if (!userId) {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }

  const user = users.find((u) => u.id === userId);
  if (!user) {
    return res.status(404).json({ success: false, message: "User not found" });
  }

  res.json({ success: true, user });
};

// Export users for other modules (in production, use database)
export { users, validateToken };
