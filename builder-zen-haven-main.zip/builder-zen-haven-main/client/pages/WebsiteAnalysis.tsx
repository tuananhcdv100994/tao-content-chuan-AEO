import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  Loader2,
  Globe,
  ArrowLeft,
  Search,
  CheckCircle2,
  XCircle,
  AlertCircle,
  BarChart3,
  Zap,
  Image,
  Link as LinkIcon,
  Smartphone,
  Clock,
  Lightbulb,
} from "lucide-react";

interface AnalysisResult {
  score: number;
  analysis: {
    title: string;
    meta: string;
    headings: string;
    content: string;
    images: string;
    links: string;
    loading: string;
    mobile: string;
    suggestions: string[];
  };
}

export default function WebsiteAnalysis() {
  const { isAuthenticated } = useAuth();
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const handleAnalyze = async () => {
    if (!url.trim()) {
      setError("Vui lòng nhập URL website");
      return;
    }

    // Basic URL validation
    try {
      new URL(url.startsWith("http") ? url : `https://${url}`);
    } catch {
      setError("URL không hợp lệ");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const response = await fetch("/api/analyze-website", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("aeo_token")}`,
        },
        body: JSON.stringify({
          url: url.startsWith("http") ? url : `https://${url}`,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setResult({
          score: data.score,
          analysis: data.analysis,
        });
      } else {
        setError(data.message || "Không thể phân tích website");
      }
    } catch (error) {
      setError("Lỗi kết nối. Vui lòng thử lại.");
    }

    setLoading(false);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-success";
    if (score >= 60) return "text-warning";
    return "text-destructive";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return "Tốt";
    if (score >= 60) return "Trung bình";
    return "Cần cải thiện";
  };

  const getRatingIcon = (rating: string) => {
    switch (rating.toLowerCase()) {
      case "tốt":
        return <CheckCircle2 className="w-4 h-4 text-success" />;
      case "trung bình":
        return <AlertCircle className="w-4 h-4 text-warning" />;
      default:
        return <XCircle className="w-4 h-4 text-destructive" />;
    }
  };

  return (
    <div className="min-h-screen bg-background grid-bg py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent rounded-full opacity-5 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary rounded-full opacity-10 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Về trang chủ
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">
              <span className="neo-text-gradient">Phân tích AEO Website</span>
            </h1>
            <p className="text-muted-foreground">
              Kiểm tra và cải thiện tối ưu hóa AEO cho website của bạn
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Analysis Input */}
          <div className="lg:col-span-1">
            <Card className="neo-border neo-glow-hover">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="w-5 h-5 mr-2 text-primary" />
                  Phân tích website
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {error && (
                  <Alert className="border-destructive">
                    <AlertDescription className="text-destructive">
                      {error}
                    </AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="url">URL Website *</Label>
                  <Input
                    id="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="VD: example.com hoặc https://example.com"
                    className="neo-border"
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !loading) {
                        handleAnalyze();
                      }
                    }}
                  />
                  <p className="text-xs text-muted-foreground">
                    Nhập URL website để phân tích tối ưu AEO
                  </p>
                </div>

                <Button
                  onClick={handleAnalyze}
                  disabled={loading}
                  className="w-full neo-gradient neo-glow-hover"
                  size="lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Đang phân tích...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Phân tích AEO
                    </>
                  )}
                </Button>

                {/* What we analyze */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold">
                    Chúng tôi phân tích:
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center space-x-2">
                      <Globe className="w-3 h-3 text-primary" />
                      <span>Tiêu đề & Meta</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <BarChart3 className="w-3 h-3 text-accent" />
                      <span>Cấu trúc nội dung</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Image className="w-3 h-3 text-warning" />
                      <span>Hình ảnh</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <LinkIcon className="w-3 h-3 text-success" />
                      <span>Liên kết</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-3 h-3 text-destructive" />
                      <span>Tốc độ tải</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Smartphone className="w-3 h-3 text-muted-foreground" />
                      <span>Tối ưu mobile</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AEO Tips */}
            <Card className="neo-border mt-6">
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <Zap className="w-4 h-4 mr-2" />
                  Mẹo tối ưu AEO
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <p>Sử dụng tiêu đề rõ ràng và mô tả ngắn gọn</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2"></div>
                  <p>Cấu trúc nội dung với heading phân cấp</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-warning rounded-full mt-2"></div>
                  <p>Tối ưu hình ảnh với alt text mô tả</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                  <p>Đảm bảo website load nhanh và mobile-friendly</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Results */}
          <div className="lg:col-span-2">
            {!result ? (
              <Card className="neo-border">
                <CardContent className="py-12">
                  <div className="text-center space-y-4">
                    <Globe className="w-16 h-16 mx-auto text-muted-foreground opacity-50" />
                    <div>
                      <h3 className="text-lg font-semibold mb-2">
                        Chưa có kết quả phân tích
                      </h3>
                      <p className="text-muted-foreground">
                        Nhập URL website và nhấn "Phân tích AEO" để bắt đầu
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {/* Overall Score */}
                <Card className="neo-border">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center">
                        <BarChart3 className="w-5 h-5 mr-2" />
                        Điểm số AEO tổng thể
                      </span>
                      <Badge
                        className={`text-lg px-3 py-1 ${
                          result.score >= 80
                            ? "bg-success text-white"
                            : result.score >= 60
                              ? "bg-warning text-white"
                              : "bg-destructive text-white"
                        }`}
                      >
                        {result.score}/100
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Điểm số AEO</span>
                          <span
                            className={`font-medium ${getScoreColor(result.score)}`}
                          >
                            {getScoreLabel(result.score)}
                          </span>
                        </div>
                        <Progress value={result.score} className="h-3" />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {result.score >= 80
                          ? "Website của bạn đã được tối ưu tốt cho AEO!"
                          : result.score >= 60
                            ? "Website có tiềm năng cải thiện AEO."
                            : "Website cần nhiều cải thiện để tối ưu AEO."}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Analysis */}
                <Card className="neo-border">
                  <CardHeader>
                    <CardTitle>Phân tích chi tiết</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Globe className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Tiêu đề & Meta
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.title)}
                            <span className="text-xs">
                              {result.analysis.title}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <BarChart3 className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Cấu trúc Heading
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.headings)}
                            <span className="text-xs">
                              {result.analysis.headings}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Image className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Tối ưu hình ảnh
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.images)}
                            <span className="text-xs">
                              {result.analysis.images}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <LinkIcon className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Liên kết
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.links)}
                            <span className="text-xs">
                              {result.analysis.links}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Globe className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Chất lượng nội dung
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.content)}
                            <span className="text-xs">
                              {result.analysis.content}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Tốc độ tải
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.loading)}
                            <span className="text-xs">
                              {result.analysis.loading}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Smartphone className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Tối ưu Mobile
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.mobile)}
                            <span className="text-xs">
                              {result.analysis.mobile}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Globe className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              Meta mô tả
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {getRatingIcon(result.analysis.meta)}
                            <span className="text-xs">
                              {result.analysis.meta}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Suggestions */}
                {result.analysis.suggestions.length > 0 && (
                  <Card className="neo-border">
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Lightbulb className="w-5 h-5 mr-2" />
                        Gợi ý cải thiện
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {result.analysis.suggestions.map(
                          (suggestion, index) => (
                            <div
                              key={index}
                              className="flex items-start space-x-3 p-3 bg-primary/5 rounded-lg"
                            >
                              <CheckCircle2 className="w-5 h-5 text-primary mt-0.5" />
                              <p className="text-sm">{suggestion}</p>
                            </div>
                          ),
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
