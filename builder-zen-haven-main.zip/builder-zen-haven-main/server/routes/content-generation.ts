import { RequestHandler } from "express";
import {
  AEOGenerationRequest,
  AEOGenerationResponse,
  ApiResponse,
} from "@shared/api";
import { z } from "zod";
import { validateToken, users } from "./auth";

const generationSchema = z.object({
  keyword: z.string().min(1).max(100),
  topic: z.string().min(1).max(100),
  length: z.number().min(100).max(5000),
  userId: z.string(),
});

const GEMINI_API_KEY = "AIzaSyANaiLoWgBxrDFJb6-5VLO4ve9ci3RHrcY";
const GEMINI_ENDPOINT =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

const generateAEOContent = async (
  keyword: string,
  topic: string,
  length: number,
): Promise<string> => {
  const prompt = `
Hãy tạo nội dung AEO (AI Engine Optimization) bằng tiếng Việt với các yêu cầu sau:

THÔNG TIN:
- Từ khóa chính: "${keyword}"
- Chủ đề: "${topic}"
- Độ dài mong muốn: ${length} ký tự

YÊU CẦU VIẾT AEO:
1. Nội dung phải được tối ưu hóa cho các công cụ tìm kiếm AI (ChatGPT, Bard, Claude, v.v.)
2. Sử dụng từ khóa chính một cách tự nhiên và phù h���p
3. Cấu trúc rõ ràng với tiêu đề và đoạn văn logic
4. Cung cấp thông tin chính xác, có giá trị và cập nhật
5. Viết theo phong cách chuyên nghiệp nhưng dễ hiểu
6. Bao gồm các thông tin hữu ích và thực tế
7. Tránh nội dung trùng lặp hoặc lan man

CẤU TRÚC BẮT BUỘC:

# [Tiêu đề chính chứa từ khóa]

## Giới thiệu
[Mở đầu hấp dẫn, giới thiệu chủ đề và tầm quan trọng]

## Nội dung chính

### [Tiêu đề phụ 1]
[Nội dung chi tiết phần 1]

### [Tiêu đề phụ 2]
[Nội dung chi tiết phần 2]

### [Tiêu đề phụ 3]
[Nội dung chi tiết phần 3]

## Lợi ích và ứng dụng
- Điểm mạnh 1
- Điểm mạnh 2
- Điểm mạnh 3

## Kết luận
[Tóm tắt lại các điểm chính và kêu gọi hành động]

LƯU Ý QUAN TRỌNG:
- Sử dụng markdown để format (# ## ### cho tiêu đề, - cho danh sách)
- Mỗi đoạn văn cách nhau bằng dòng trống
- Tiêu đề rõ ràng, hấp dẫn
- Nội dung có cấu trúc logic, dễ đọc
- Đảm bảo độ dài khoảng ${length} ký tự

Hãy tạo nội dung AEO đẹp mắt, có cấu trúc rõ ràng và tối ưu cho AI.
`;

  try {
    const response = await fetch(GEMINI_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: Math.ceil(length * 1.5), // Allow some buffer
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();

    if (
      data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts &&
      data.candidates[0].content.parts[0]
    ) {
      let content = data.candidates[0].content.parts[0].text;

      // Clean up the content
      content = content.trim();

      // If content is too long, truncate it
      if (content.length > length * 1.2) {
        content = content.substring(0, length) + "...";
      }

      return content;
    } else {
      throw new Error("Invalid response format from Gemini API");
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Không thể tạo nội dung. Vui lòng thử lại.");
  }
};

export const handleGenerateContent: RequestHandler = async (req, res) => {
  try {
    // Validate authentication
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    // Find user
    const userIndex = users.findIndex((u) => u.id === userId);
    if (userIndex === -1) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const user = users[userIndex];

    // Check usage limits
    if (user.usageCount >= user.maxUsage) {
      const response: AEOGenerationResponse = {
        success: false,
        message: "Bạn đã hết lượt sử dụng. Vui lòng nâng cấp tài khoản.",
      };
      return res.status(429).json(response);
    }

    // Validate request data
    const { keyword, topic, length } = generationSchema.parse(req.body);

    // Generate content using Gemini API
    const content = await generateAEOContent(keyword, topic, length);

    // Update user usage
    users[userIndex].usageCount += 1;
    const remainingUsage = user.maxUsage - users[userIndex].usageCount;

    const response: AEOGenerationResponse = {
      success: true,
      content,
      remainingUsage,
    };

    res.json(response);
  } catch (error) {
    console.error("Content generation error:", error);

    if (error instanceof z.ZodError) {
      const response: AEOGenerationResponse = {
        success: false,
        message: "Dữ liệu đầu vào không hợp lệ",
      };
      return res.status(400).json(response);
    }

    const response: AEOGenerationResponse = {
      success: false,
      message:
        error instanceof Error
          ? error.message
          : "Có lỗi xảy ra khi tạo nội dung",
    };

    res.status(500).json(response);
  }
};

// Keyword suggestion endpoint
export const handleKeywordSuggestions: RequestHandler = async (req, res) => {
  try {
    // Validate authentication
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Token required" });
    }

    const userId = validateToken(token);
    if (!userId) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    const { keyword } = req.query;

    if (!keyword || typeof keyword !== "string") {
      return res
        .status(400)
        .json({ success: false, message: "Keyword required" });
    }

    const prompt = `
Hãy đề xuất 10 từ khóa liên quan đến "${keyword}" cho mục đích SEO và AEO tại Việt Nam.

Trả về định dạng JSON như sau:
{
  "suggestions": [
    {
      "keyword": "từ khóa 1",
      "searchVolume": 1000,
      "difficulty": "Dễ"
    }
  ]
}

Các từ khóa nên:
- Liên quan chặt chẽ đến từ khóa gốc
- Phù hợp với thị trường Việt Nam
- Có tiềm năng tìm kiếm cao
- Đa dạng về độ khó (Dễ, Trung bình, Khó)
`;

    const response = await fetch(GEMINI_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.8,
          topK: 40,
          topP: 0.95,
        },
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to get keyword suggestions");
    }

    const data = await response.json();
    let suggestions = [];

    try {
      const content = data.candidates[0].content.parts[0].text;
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        suggestions = parsed.suggestions || [];
      }
    } catch (parseError) {
      console.error("Keyword parsing error:", parseError);
      // Fallback suggestions if AI response can't be parsed
      suggestions = [
        {
          keyword: `${keyword} là gì`,
          searchVolume: 800,
          difficulty: "Dễ",
          relatedKeywords: [`tìm hiểu ${keyword}`, `${keyword} cơ bản`],
        },
        {
          keyword: `cách ${keyword}`,
          searchVolume: 600,
          difficulty: "Trung bình",
          relatedKeywords: [`hướng dẫn ${keyword}`, `${keyword} cho người mới`],
        },
        {
          keyword: `${keyword} hiệu quả`,
          searchVolume: 400,
          difficulty: "Trung bình",
          relatedKeywords: [`${keyword} tốt nhất`, `${keyword} chuyên nghiệp`],
        },
        {
          keyword: `${keyword} miễn phí`,
          searchVolume: 350,
          difficulty: "Dễ",
          relatedKeywords: [`${keyword} không mất phí`, `${keyword} free`],
        },
        {
          keyword: `${keyword} online`,
          searchVolume: 500,
          difficulty: "Trung bình",
          relatedKeywords: [`${keyword} trực tuyến`, `${keyword} web`],
        },
      ];
    }

    res.json({ success: true, data: { keywords: suggestions } });
  } catch (error) {
    console.error("Keyword suggestion error:", error);
    res.status(500).json({
      success: false,
      message: "Không thể tạo gợi ý từ khóa",
    });
  }
};
