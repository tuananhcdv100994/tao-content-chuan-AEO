import React, { createContext, useContext, useState, useEffect } from "react";
import { User, AuthResponse } from "@shared/api";

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<AuthResponse>;
  register: (data: {
    username: string;
    email: string;
    name: string;
    phone: string;
    password: string;
  }) => Promise<AuthResponse>;
  logout: (redirectToLogin?: boolean) => void;
  loading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing token and validate it
    const token = localStorage.getItem("aeo_token");
    const userData = localStorage.getItem("aeo_user");

    if (token && userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
      } catch (error) {
        localStorage.removeItem("aeo_token");
        localStorage.removeItem("aeo_user");
      }
    }
    setLoading(false);
  }, []);

  const login = async (
    username: string,
    password: string,
  ): Promise<AuthResponse> => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const result: AuthResponse = await response.json();

      if (result.success && result.user && result.token) {
        setUser(result.user);
        localStorage.setItem("aeo_token", result.token);
        localStorage.setItem("aeo_user", JSON.stringify(result.user));
      }

      return result;
    } catch (error) {
      return {
        success: false,
        message: "Lỗi kết nối. Vui lòng thử lại.",
      };
    }
  };

  const register = async (data: {
    username: string;
    email: string;
    name: string;
    phone: string;
    password: string;
  }): Promise<AuthResponse> => {
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result: AuthResponse = await response.json();

      if (result.success && result.user && result.token) {
        setUser(result.user);
        localStorage.setItem("aeo_token", result.token);
        localStorage.setItem("aeo_user", JSON.stringify(result.user));
      }

      return result;
    } catch (error) {
      return {
        success: false,
        message: "Lỗi kết nối. Vui lòng thử lại.",
      };
    }
  };

  const logout = (redirectToLogin: boolean = true) => {
    setUser(null);
    localStorage.removeItem("aeo_token");
    localStorage.removeItem("aeo_user");

    if (redirectToLogin) {
      // Force redirect to login page
      window.location.href = "/login";
    }
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    loading,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
