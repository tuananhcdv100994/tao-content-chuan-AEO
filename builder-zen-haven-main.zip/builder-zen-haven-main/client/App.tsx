import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";

// Pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminLogin from "./pages/AdminLogin";
import Upgrade from "./pages/Upgrade";
import AdminDashboard from "./pages/AdminDashboard";
import KeywordIdeas from "./pages/KeywordIdeas";
import UserGuide from "./pages/UserGuide";
import WebsiteAnalysis from "./pages/WebsiteAnalysis";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <div className="dark min-h-screen">
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/admin-login" element={<AdminLogin />} />
              {/* Placeholder routes for future features */}
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/upgrade" element={<Upgrade />} />
              <Route path="/keyword-ideas" element={<KeywordIdeas />} />
              <Route path="/website-analysis" element={<WebsiteAnalysis />} />
              <Route path="/guide" element={<UserGuide />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </div>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

// Placeholder component for routes that will be implemented later
const PlaceholderPage = ({ title }: { title: string }) => (
  <div className="min-h-screen bg-background grid-bg flex items-center justify-center p-4">
    <div className="text-center space-y-4">
      <h1 className="text-3xl font-bold neo-text-gradient">{title}</h1>
      <p className="text-muted-foreground">
        Tính năng này đang được phát triển. Vui lòng quay lại sau.
      </p>
      <button
        onClick={() => window.history.back()}
        className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
      >
        Quay lại
      </button>
    </div>
  </div>
);

createRoot(document.getElementById("root")!).render(<App />);
