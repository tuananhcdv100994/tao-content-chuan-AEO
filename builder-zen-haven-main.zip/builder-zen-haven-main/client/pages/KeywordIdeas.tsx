import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Loader2,
  Search,
  ArrowLeft,
  TrendingUp,
  Lightbulb,
  Copy,
  RefreshCw,
  BarChart3,
} from "lucide-react";

interface KeywordSuggestion {
  keyword: string;
  searchVolume: number;
  difficulty: "Dễ" | "Trung bình" | "Khó";
  relatedKeywords: string[];
}

export default function KeywordIdeas() {
  const { isAuthenticated } = useAuth();
  const [seedKeyword, setSeedKeyword] = useState("");
  const [suggestions, setSuggestions] = useState<KeywordSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const handleGenerateIdeas = async () => {
    if (!seedKeyword.trim()) {
      setError("Vui lòng nhập từ khóa mẫu");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const response = await fetch(
        `/api/keyword-suggestions?keyword=${encodeURIComponent(seedKeyword.trim())}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("aeo_token")}`,
          },
        },
      );

      const result = await response.json();

      if (result.success && result.data?.keywords) {
        setSuggestions(result.data.keywords);
        setSuccess(
          `Đã tạo ${result.data.keywords.length} ý tưởng từ khóa thành công!`,
        );
      } else {
        setError(result.message || "Không thể tạo ý tưởng từ khóa");
      }
    } catch (error) {
      setError("Lỗi kết nối. Vui lòng thử lại.");
    }

    setLoading(false);
  };

  const handleCopyKeyword = async (keyword: string) => {
    try {
      await navigator.clipboard.writeText(keyword);
      setSuccess(`Đã sao chép "${keyword}" vào clipboard!`);
      setTimeout(() => setSuccess(""), 3000);
    } catch (error) {
      setError("Không thể sao chép từ khóa");
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Dễ":
        return "bg-success text-white";
      case "Trung bình":
        return "bg-warning text-white";
      case "Khó":
        return "bg-destructive text-white";
      default:
        return "bg-muted";
    }
  };

  const getVolumeColor = (volume: number) => {
    if (volume >= 1000) return "text-success";
    if (volume >= 500) return "text-warning";
    return "text-muted-foreground";
  };

  return (
    <div className="min-h-screen bg-background grid-bg py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent rounded-full opacity-5 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary rounded-full opacity-10 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Về trang chủ
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">
              <span className="neo-text-gradient">Ý tưởng từ khóa AI</span>
            </h1>
            <p className="text-muted-foreground">
              Khám phá từ khóa tiềm năng với sức mạnh của AI
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Keyword Input */}
          <div className="lg:col-span-1">
            <Card className="neo-border neo-glow-hover">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Search className="w-5 h-5 mr-2 text-primary" />
                  Nhập từ khóa mẫu
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {(error || success) && (
                  <Alert
                    className={error ? "border-destructive" : "border-success"}
                  >
                    <AlertDescription
                      className={error ? "text-destructive" : "text-success"}
                    >
                      {error || success}
                    </AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="seedKeyword">Từ khóa chính *</Label>
                  <Input
                    id="seedKeyword"
                    value={seedKeyword}
                    onChange={(e) => setSeedKeyword(e.target.value)}
                    placeholder="VD: SEO, marketing online, kinh doanh..."
                    className="neo-border"
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !loading) {
                        handleGenerateIdeas();
                      }
                    }}
                  />
                  <p className="text-xs text-muted-foreground">
                    Nhập từ khóa chính để AI tạo ra các ý tưởng liên quan
                  </p>
                </div>

                <Button
                  onClick={handleGenerateIdeas}
                  disabled={loading}
                  className="w-full neo-gradient neo-glow-hover"
                  size="lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Đang tạo ý tưởng...
                    </>
                  ) : (
                    <>
                      <Lightbulb className="w-5 h-5 mr-2" />
                      Tạo ý tưởng từ khóa
                    </>
                  )}
                </Button>

                {/* Examples */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold">Ví dụ từ khóa:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      "SEO website",
                      "Marketing online",
                      "Kinh doanh nhỏ",
                      "Đầu tư tài chính",
                      "Du lịch Việt Nam",
                      "Làm đẹp tự nhiên",
                    ].map((example) => (
                      <Button
                        key={example}
                        variant="outline"
                        size="sm"
                        className="text-xs neo-border justify-start"
                        onClick={() => setSeedKeyword(example)}
                      >
                        {example}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Guide */}
            <Card className="neo-border mt-6">
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Cách sử dụng hiệu quả
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <p>Sử dụng từ khóa chính rộng để có nhiều ý tưởng</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2"></div>
                  <p>Chọn từ khóa phù hợp với nội dung của bạn</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-warning rounded-full mt-2"></div>
                  <p>Ưu tiên từ khóa có lượng tìm kiếm cao và độ khó thấp</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="lg:col-span-2">
            {suggestions.length === 0 ? (
              <Card className="neo-border">
                <CardContent className="py-12">
                  <div className="text-center space-y-4">
                    <Search className="w-16 h-16 mx-auto text-muted-foreground opacity-50" />
                    <div>
                      <h3 className="text-lg font-semibold mb-2">
                        Chưa có ý tưởng từ khóa
                      </h3>
                      <p className="text-muted-foreground">
                        Nhập từ khóa mẫu và nhấn "Tạo ý tưởng từ khóa" để bắt
                        đầu
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="neo-border">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <BarChart3 className="w-5 h-5 mr-2" />Ý tưởng từ khóa (
                      {suggestions.length})
                    </CardTitle>
                    <Button
                      onClick={handleGenerateIdeas}
                      variant="outline"
                      size="sm"
                      className="neo-border"
                      disabled={loading}
                    >
                      <RefreshCw className="w-4 h-4 mr-1" />
                      Làm mới
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border border-border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Từ khóa</TableHead>
                          <TableHead>Lượng tìm kiếm</TableHead>
                          <TableHead>Độ khó</TableHead>
                          <TableHead>Thao tác</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {suggestions.map((suggestion, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-medium">
                                  {suggestion.keyword}
                                </div>
                                {suggestion.relatedKeywords.length > 0 && (
                                  <div className="flex flex-wrap gap-1">
                                    {suggestion.relatedKeywords
                                      .slice(0, 2)
                                      .map((related, idx) => (
                                        <Badge
                                          key={idx}
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          {related}
                                        </Badge>
                                      ))}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div
                                className={`font-medium ${getVolumeColor(suggestion.searchVolume)}`}
                              >
                                {suggestion.searchVolume.toLocaleString()}
                                /tháng
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge
                                className={getDifficultyColor(
                                  suggestion.difficulty,
                                )}
                              >
                                {suggestion.difficulty}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() =>
                                    handleCopyKeyword(suggestion.keyword)
                                  }
                                  className="neo-border"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    // Navigate to main page with this keyword
                                    const searchParams = new URLSearchParams();
                                    searchParams.set(
                                      "keyword",
                                      suggestion.keyword,
                                    );
                                    window.location.href = `/?${searchParams.toString()}`;
                                  }}
                                  className="neo-border text-xs"
                                >
                                  Tạo nội dung
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Statistics Summary */}
                  <div className="mt-6 grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-muted/20 rounded-lg">
                      <div className="text-lg font-bold text-success">
                        {
                          suggestions.filter((s) => s.difficulty === "Dễ")
                            .length
                        }
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Từ khóa dễ
                      </div>
                    </div>
                    <div className="text-center p-4 bg-muted/20 rounded-lg">
                      <div className="text-lg font-bold text-warning">
                        {
                          suggestions.filter(
                            (s) => s.difficulty === "Trung bình",
                          ).length
                        }
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Trung bình
                      </div>
                    </div>
                    <div className="text-center p-4 bg-muted/20 rounded-lg">
                      <div className="text-lg font-bold text-primary">
                        {Math.round(
                          suggestions.reduce(
                            (sum, s) => sum + s.searchVolume,
                            0,
                          ) / suggestions.length,
                        ).toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        TB lượng tìm kiếm
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
