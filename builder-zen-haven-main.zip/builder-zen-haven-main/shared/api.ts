/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

// User and Authentication Types
export interface User {
  id: string;
  username: string;
  email: string;
  name: string;
  phone: string;
  role: "user" | "admin";
  plan: "free" | "premium";
  usageCount: number;
  maxUsage: number;
  createdAt: string;
  lastLogin?: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  name: string;
  phone: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  user?: User;
  token?: string;
  message?: string;
}

// AEO Content Generation Types
export interface AEOGenerationRequest {
  keyword: string;
  topic: string;
  length: number;
  userId: string;
}

export interface AEOGenerationResponse {
  success: boolean;
  content?: string;
  remainingUsage?: number;
  message?: string;
}

// Keyword and Topic Suggestions
export interface KeywordSuggestion {
  keyword: string;
  searchVolume?: number;
  difficulty?: string;
  relatedKeywords?: string[];
}

export interface TopicSuggestion {
  topic: string;
  description: string;
  keywords: string[];
}

export interface SuggestionsResponse {
  keywords?: KeywordSuggestion[];
  topics?: TopicSuggestion[];
}

// Website AEO Analysis
export interface WebsiteAnalysisRequest {
  url: string;
  userId: string;
}

export interface WebsiteAnalysisResponse {
  success: boolean;
  score?: number;
  analysis?: {
    title: string;
    meta: string;
    headings: string;
    content: string;
    images: string;
    links: string;
    loading: string;
    mobile: string;
    suggestions: string[];
  };
  message?: string;
}

// Upgrade and Payment Types
export interface UpgradeRequest {
  userId: string;
  name: string;
  phone: string;
  email: string;
  plan: "premium";
}

export interface UpgradeResponse {
  success: boolean;
  message: string;
  paymentInfo?: {
    amount: number;
    currency: string;
    contact: string;
  };
}

// Admin Types
export interface AdminStats {
  totalUsers: number;
  freeUsers: number;
  premiumUsers: number;
  totalGenerations: number;
  dailyUsage: { date: string; count: number }[];
  monthlyUsage: { month: string; count: number }[];
  yearlyUsage: { year: string; count: number }[];
}

export interface AdminUserAction {
  userId: string;
  action: "upgrade" | "downgrade" | "delete" | "reset-usage";
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

// User History and Storage
export interface UserHistory {
  keywords: string[];
  topics: string[];
  generatedContent: {
    id: string;
    keyword: string;
    topic: string;
    content: string;
    createdAt: string;
  }[];
}

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}
