import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleLogin, handleRegister, handleGetProfile } from "./routes/auth";
import {
  handleGenerateContent,
  handleKeywordSuggestions,
} from "./routes/content-generation";
import {
  handleUpgrade,
  handleApproveUpgrade,
  handleGetUpgradeRequests,
} from "./routes/upgrade";
import {
  handleGetAllUsers,
  handleGetAdminStats,
  handleUserAction,
  handleGetSystemInfo,
} from "./routes/admin";
import { handleWebsiteAnalysis } from "./routes/website-analysis";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    res.json({ message: "Hello from Express server v2!" });
  });

  app.get("/api/demo", handleDemo);

  // Authentication routes
  app.post("/api/auth/login", handleLogin);
  app.post("/api/auth/register", handleRegister);
  app.get("/api/auth/profile", handleGetProfile);

  // Content generation routes
  app.post("/api/generate-content", handleGenerateContent);
  app.get("/api/keyword-suggestions", handleKeywordSuggestions);

  // Upgrade routes
  app.post("/api/upgrade", handleUpgrade);
  app.post("/api/admin/approve-upgrade", handleApproveUpgrade);
  app.get("/api/admin/upgrade-requests", handleGetUpgradeRequests);

  // Admin routes
  app.get("/api/admin/users", handleGetAllUsers);
  app.get("/api/admin/stats", handleGetAdminStats);
  app.post("/api/admin/user-action", handleUserAction);
  app.get("/api/admin/system-info", handleGetSystemInfo);

  // Website analysis route
  app.post("/api/analyze-website", handleWebsiteAnalysis);

  return app;
}
