import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Alert, AlertDescription } from "../components/ui/alert";
import { Loader2, Shield, Crown, ArrowLeft } from "lucide-react";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const result = await login(username, password);

    if (result.success && result.user?.role === "admin") {
      navigate("/admin");
    } else if (result.success) {
      setError("Tài khoản này không có quyền quản trị");
    } else {
      setError(result.message || "Đăng nhập thất bại");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-background grid-bg flex items-center justify-center p-4">
      {/* Enhanced background effects for admin */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-warning rounded-full opacity-5 blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary rounded-full opacity-10 blur-3xl"></div>
        <div className="absolute top-3/4 left-3/4 w-60 h-60 bg-accent rounded-full opacity-5 blur-2xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to="/login"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Về trang đăng nhập thường
          </Link>
        </div>

        {/* Admin Brand Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <div className="w-16 h-16 bg-gradient-to-br from-warning to-primary rounded-full flex items-center justify-center shadow-2xl">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <Crown className="w-6 h-6 text-warning absolute -top-1 -right-1 animate-pulse" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-2">
            <span className="bg-gradient-to-r from-warning via-primary to-accent bg-clip-text text-transparent">
              Quản trị hệ thống
            </span>
          </h1>
          <p className="text-sm text-muted-foreground">
            Khu vực dành riêng cho quản trị viên
          </p>
        </div>

        <Card className="border-warning/20 bg-card/90 backdrop-blur-xl shadow-2xl">
          <CardHeader className="space-y-1 bg-gradient-to-r from-warning/10 to-primary/10 rounded-t-lg">
            <CardTitle className="text-2xl text-center flex items-center justify-center">
              <Shield className="w-6 h-6 mr-2 text-warning" />
              Đăng nhập quản trị
            </CardTitle>
            <p className="text-center text-muted-foreground">
              Chỉ dành cho quản trị viên có thẩm quyền
            </p>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert className="border-destructive bg-destructive/10">
                  <AlertDescription className="text-destructive">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="text-sm font-medium">
                  Tên đăng nhập quản trị
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="border-warning/30 focus:border-warning focus:ring-warning/20 bg-background/50"
                  placeholder="Nhập tên đăng nhập quản trị"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  Mật khẩu quản trị
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-warning/30 focus:border-warning focus:ring-warning/20 bg-background/50"
                  placeholder="Nhập mật khẩu quản trị"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-warning to-primary hover:from-warning/90 hover:to-primary/90 text-white shadow-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Đang xác thực...
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4 mr-2" />
                    Truy cập hệ thống
                  </>
                )}
              </Button>
            </form>

            {/* Security Notice */}
            <div className="mt-6 p-4 bg-warning/10 border border-warning/20 rounded-lg">
              <p className="text-xs text-center text-warning">
                ⚠️ Khu vực bảo mật cao. Mọi hoạt động đều được ghi lại.
              </p>
            </div>

            {/* Admin Info */}
            <div className="mt-4 text-center">
              <p className="text-xs text-muted-foreground">
                Quên thông tin đăng nhập?{" "}
                <a
                  href="https://zalo.me/0792762794"
                  className="text-warning hover:text-primary transition-colors"
                >
                  Liên hệ hỗ trợ
                </a>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Admin Features Preview */}
        <div className="mt-8 grid grid-cols-2 gap-4 text-center">
          <div className="p-3 bg-card/50 rounded-lg border border-border/50">
            <p className="text-xs text-muted-foreground">Quản lý</p>
            <p className="text-sm font-medium text-warning">Người dùng</p>
          </div>
          <div className="p-3 bg-card/50 rounded-lg border border-border/50">
            <p className="text-xs text-muted-foreground">Thống kê</p>
            <p className="text-sm font-medium text-primary">Hệ thống</p>
          </div>
        </div>
      </div>
    </div>
  );
}
