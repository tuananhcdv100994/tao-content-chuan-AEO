import React from "react";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Badge } from "./ui/badge";
import {
  User,
  LogOut,
  Crown,
  Settings,
  BarChart3,
  ChevronDown,
} from "lucide-react";

export const UserProfileDropdown: React.FC = () => {
  const { user, logout, isAdmin } = useAuth();

  if (!user) return null;

  const usagePercentage = (user.usageCount / user.maxUsage) * 100;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center space-x-2 hover:bg-muted/50"
        >
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="hidden md:block text-left">
            <div className="flex items-center space-x-1">
              <span className="text-sm font-medium">{user.name}</span>
              {user.plan === "premium" && (
                <Crown className="w-3 h-3 text-warning" />
              )}
              {isAdmin && <Settings className="w-3 h-3 text-primary" />}
            </div>
            <div className="text-xs text-muted-foreground">
              {user.plan === "premium" ? "Premium" : "Miễn phí"}
              {isAdmin && " • Admin"}
            </div>
          </div>
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-64 neo-border">
        {/* User Info */}
        <DropdownMenuLabel>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-1">
                  <span className="font-semibold">{user.name}</span>
                  {user.plan === "premium" && (
                    <Crown className="w-3 h-3 text-warning" />
                  )}
                  {isAdmin && <Settings className="w-3 h-3 text-primary" />}
                </div>
                <div className="text-xs text-muted-foreground">
                  @{user.username}
                </div>
              </div>
            </div>

            {/* Account Type */}
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                Loại tài khoản:
              </span>
              <Badge
                variant={user.plan === "premium" ? "default" : "secondary"}
                className={`text-xs ${user.plan === "premium" ? "neo-gradient" : ""}`}
              >
                {user.plan === "premium" ? (
                  <>
                    <Crown className="w-3 h-3 mr-1" />
                    Premium
                  </>
                ) : (
                  "Miễn phí"
                )}
              </Badge>
            </div>

            {/* Usage Stats */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Đã sử dụng:</span>
                <span className="font-medium">
                  {user.usageCount}/{user.maxUsage}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-1.5">
                <div
                  className="bg-gradient-to-r from-primary to-accent h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(usagePercentage, 100)}%` }}
                ></div>
              </div>
              <div className="text-xs text-muted-foreground">
                Còn lại: {user.maxUsage - user.usageCount} lượt
              </div>
            </div>
          </div>
        </DropdownMenuLabel>

        <DropdownMenuSeparator />

        {/* Admin Panel Access */}
        {isAdmin && (
          <>
            <DropdownMenuItem
              onClick={() => (window.location.href = "/admin")}
              className="cursor-pointer"
            >
              <Settings className="w-4 h-4 mr-2" />
              Quản trị hệ thống
            </DropdownMenuItem>
            <DropdownMenuSeparator />
          </>
        )}

        {/* Account Actions */}
        <DropdownMenuItem
          onClick={() => (window.location.href = "/")}
          className="cursor-pointer"
        >
          <BarChart3 className="w-4 h-4 mr-2" />
          Dashboard
        </DropdownMenuItem>

        {user.plan === "free" && (
          <DropdownMenuItem
            onClick={() => (window.location.href = "/upgrade")}
            className="cursor-pointer text-primary"
          >
            <Crown className="w-4 h-4 mr-2" />
            Nâng cấp Premium
          </DropdownMenuItem>
        )}

        <DropdownMenuSeparator />

        {/* Account Info */}
        <div className="px-2 py-1">
          <div className="text-xs text-muted-foreground space-y-1">
            <div>Email: {user.email}</div>
            <div>SĐT: {user.phone}</div>
            {user.lastLogin && (
              <div>
                Đăng nhập:{" "}
                {new Date(user.lastLogin).toLocaleDateString("vi-VN")}
              </div>
            )}
          </div>
        </div>

        <DropdownMenuSeparator />

        {/* Logout */}
        <DropdownMenuItem
          onClick={() => logout()}
          className="cursor-pointer text-destructive focus:text-destructive"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Đăng xuất
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
