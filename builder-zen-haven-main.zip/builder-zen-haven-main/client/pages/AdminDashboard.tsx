import React, { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import {
  Shield,
  Users,
  BarChart3,
  Crown,
  UserX,
  UserCheck,
  RefreshCw,
  TrendingUp,
  Calendar,
  Zap,
  LogOut,
  ArrowUpDown,
  CheckCircle2,
  XCircle,
  Loader2,
} from "lucide-react";
import { User, AdminStats } from "@shared/api";
import { UserProfileDropdown } from "../components/UserProfileDropdown";

export default function AdminDashboard() {
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [upgradeRequests, setUpgradeRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Redirect if not authenticated or not admin
  if (!isAuthenticated || !isAdmin) {
    return <Navigate to="/admin-login" replace />;
  }

  // Load admin data
  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("aeo_token");
      const headers = {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      };

      // Load users, stats, and upgrade requests in parallel
      const [usersRes, statsRes, upgradeRes] = await Promise.all([
        fetch("/api/admin/users", { headers }),
        fetch("/api/admin/stats", { headers }),
        fetch("/api/admin/upgrade-requests", { headers }),
      ]);

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData.data || []);
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData.data);
      }

      if (upgradeRes.ok) {
        const upgradeData = await upgradeRes.json();
        setUpgradeRequests(upgradeData.data || []);
      }
    } catch (error) {
      setError("Lỗi tải dữ liệu admin");
      console.error("Admin data loading error:", error);
    }
    setLoading(false);
  };

  const handleUserAction = async (
    userId: string,
    action: "upgrade" | "downgrade" | "delete" | "reset-usage",
  ) => {
    setActionLoading(userId);
    setError("");
    setSuccess("");

    try {
      const token = localStorage.getItem("aeo_token");
      const response = await fetch("/api/admin/user-action", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId, action }),
      });

      const result = await response.json();

      if (result.success) {
        setSuccess(
          `Thực hiện thành công: ${action === "upgrade" ? "nâng cấp" : action === "downgrade" ? "hạ cấp" : action === "delete" ? "xóa" : "reset"} tài khoản`,
        );
        await loadAdminData(); // Reload data
      } else {
        setError(result.message || "Có lỗi xảy ra");
      }
    } catch (error) {
      setError("Lỗi kết nối");
    }

    setActionLoading(null);
  };

  const handleApproveUpgrade = async (upgradeRequestId: string) => {
    setActionLoading(upgradeRequestId);
    try {
      const token = localStorage.getItem("aeo_token");
      const response = await fetch("/api/admin/approve-upgrade", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ upgradeRequestId }),
      });

      const result = await response.json();

      if (result.success) {
        setSuccess("Đã duyệt yêu cầu nâng cấp thành công");
        await loadAdminData();
      } else {
        setError(result.message || "Có lỗi xảy ra");
      }
    } catch (error) {
      setError("Lỗi kết nối");
    }
    setActionLoading(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("vi-VN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background grid-bg flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Đang tải dữ liệu admin...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background grid-bg">
      {/* Admin Header */}
      <header className="border-b border-warning/20 bg-gradient-to-r from-card/50 to-card/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-warning to-primary rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">
                  <span className="bg-gradient-to-r from-warning via-primary to-accent bg-clip-text text-transparent">
                    Admin Dashboard
                  </span>
                </h1>
                <p className="text-xs text-muted-foreground">
                  Quản trị hệ thống AEO
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <UserProfileDropdown />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Alerts */}
        {(error || success) && (
          <Alert
            className={`mb-6 ${error ? "border-destructive" : "border-success"}`}
          >
            <AlertDescription
              className={error ? "text-destructive" : "text-success"}
            >
              {error || success}
            </AlertDescription>
          </Alert>
        )}

        {/* Stats Overview */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="neo-border bg-gradient-to-br from-primary/10 to-primary/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Tổng người dùng
                    </p>
                    <p className="text-2xl font-bold text-primary">
                      {stats.totalUsers}
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="neo-border bg-gradient-to-br from-accent/10 to-accent/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Người dùng Premium
                    </p>
                    <p className="text-2xl font-bold text-accent">
                      {stats.premiumUsers}
                    </p>
                  </div>
                  <Crown className="w-8 h-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card className="neo-border bg-gradient-to-br from-warning/10 to-warning/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Tổng sinh nội dung
                    </p>
                    <p className="text-2xl font-bold text-warning">
                      {stats.totalGenerations}
                    </p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card className="neo-border bg-gradient-to-br from-success/10 to-success/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Yêu cầu nâng cấp
                    </p>
                    <p className="text-2xl font-bold text-success">
                      {upgradeRequests.length}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-success" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[400px] bg-card">
            <TabsTrigger value="users">Người dùng</TabsTrigger>
            <TabsTrigger value="upgrades">Nâng cấp</TabsTrigger>
            <TabsTrigger value="stats">Thống kê</TabsTrigger>
            <TabsTrigger value="reports">Báo cáo</TabsTrigger>
          </TabsList>

          {/* Users Management */}
          <TabsContent value="users">
            <Card className="neo-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Quản lý người dùng
                  </CardTitle>
                  <Button
                    onClick={loadAdminData}
                    variant="outline"
                    size="sm"
                    className="neo-border"
                  >
                    <RefreshCw className="w-4 h-4 mr-1" />
                    Làm mới
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tên đăng nhập</TableHead>
                        <TableHead>Họ tên</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Gói</TableHead>
                        <TableHead>Sử dụng</TableHead>
                        <TableHead>Ngày tạo</TableHead>
                        <TableHead>Thao tác</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users
                        .filter((u) => u.role !== "admin")
                        .map((user) => (
                          <TableRow key={user.id}>
                            <TableCell className="font-medium">
                              {user.username}
                            </TableCell>
                            <TableCell>{user.name}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  user.plan === "premium"
                                    ? "default"
                                    : "secondary"
                                }
                                className={
                                  user.plan === "premium" ? "neo-gradient" : ""
                                }
                              >
                                {user.plan === "premium" ? (
                                  <>
                                    <Crown className="w-3 h-3 mr-1" />
                                    Premium
                                  </>
                                ) : (
                                  "Miễn phí"
                                )}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="text-sm">
                                  {user.usageCount}/{user.maxUsage}
                                </div>
                                <Progress
                                  value={
                                    (user.usageCount / user.maxUsage) * 100
                                  }
                                  className="h-2 w-20"
                                />
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">
                              {formatDate(user.createdAt)}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                {user.plan === "free" ? (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() =>
                                      handleUserAction(user.id, "upgrade")
                                    }
                                    disabled={actionLoading === user.id}
                                    className="text-xs neo-border"
                                  >
                                    {actionLoading === user.id ? (
                                      <Loader2 className="w-3 h-3 animate-spin" />
                                    ) : (
                                      <UserCheck className="w-3 h-3" />
                                    )}
                                  </Button>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() =>
                                      handleUserAction(user.id, "downgrade")
                                    }
                                    disabled={actionLoading === user.id}
                                    className="text-xs neo-border"
                                  >
                                    {actionLoading === user.id ? (
                                      <Loader2 className="w-3 h-3 animate-spin" />
                                    ) : (
                                      <ArrowUpDown className="w-3 h-3" />
                                    )}
                                  </Button>
                                )}

                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() =>
                                    handleUserAction(user.id, "reset-usage")
                                  }
                                  disabled={actionLoading === user.id}
                                  className="text-xs neo-border"
                                >
                                  {actionLoading === user.id ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <RefreshCw className="w-3 h-3" />
                                  )}
                                </Button>

                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() =>
                                    handleUserAction(user.id, "delete")
                                  }
                                  disabled={actionLoading === user.id}
                                  className="text-xs"
                                >
                                  {actionLoading === user.id ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <UserX className="w-3 h-3" />
                                  )}
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Upgrade Requests */}
          <TabsContent value="upgrades">
            <Card className="neo-border">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Crown className="w-5 h-5 mr-2" />
                  Yêu cầu nâng cấp Premium
                </CardTitle>
              </CardHeader>
              <CardContent>
                {upgradeRequests.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Không có yêu cầu nâng cấp nào
                  </div>
                ) : (
                  <div className="rounded-md border border-border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tên</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Số điện thoại</TableHead>
                          <TableHead>Gói</TableHead>
                          <TableHead>Ngày yêu cầu</TableHead>
                          <TableHead>Thao tác</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {upgradeRequests.map((request) => (
                          <TableRow key={request.id}>
                            <TableCell className="font-medium">
                              {request.name}
                            </TableCell>
                            <TableCell>{request.email}</TableCell>
                            <TableCell>{request.phone}</TableCell>
                            <TableCell>
                              <Badge className="neo-gradient">
                                <Crown className="w-3 h-3 mr-1" />
                                Premium - 299,000₫
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">
                              {formatDate(request.createdAt)}
                            </TableCell>
                            <TableCell>
                              <Button
                                size="sm"
                                onClick={() => handleApproveUpgrade(request.id)}
                                disabled={actionLoading === request.id}
                                className="neo-gradient text-xs"
                              >
                                {actionLoading === request.id ? (
                                  <>
                                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                                    Đang duyệt...
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle2 className="w-3 h-3 mr-1" />
                                    Duyệt
                                  </>
                                )}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Statistics */}
          <TabsContent value="stats">
            <div className="grid gap-6">
              <Card className="neo-border">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Thống kê tổng quan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-semibold">Phân bố người dùng</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Miễn phí:</span>
                          <span className="font-medium">
                            {stats?.freeUsers || 0}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Premium:</span>
                          <span className="font-medium text-primary">
                            {stats?.premiumUsers || 0}
                          </span>
                        </div>
                        <Progress
                          value={
                            stats?.totalUsers
                              ? (stats.premiumUsers / stats.totalUsers) * 100
                              : 0
                          }
                          className="h-2"
                        />
                        <p className="text-xs text-muted-foreground">
                          {stats?.totalUsers
                            ? (
                                (stats.premiumUsers / stats.totalUsers) *
                                100
                              ).toFixed(1)
                            : 0}
                          % người dùng Premium
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold">Hoạt động hệ thống</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Tổng nội dung đã tạo:</span>
                          <span className="font-medium">
                            {stats?.totalGenerations || 0}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Trung bình/người dùng:</span>
                          <span className="font-medium">
                            {stats?.totalUsers
                              ? Math.round(
                                  (stats.totalGenerations || 0) /
                                    stats.totalUsers,
                                )
                              : 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Reports */}
          <TabsContent value="reports">
            <Card className="neo-border">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Báo cáo chi tiết
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Tính năng báo cáo chi tiết đang được phát triển</p>
                  <p className="text-sm mt-2">
                    Sẽ bao gồm biểu đồ theo ngày, tháng, năm
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
