import React from "react";
import { Link } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import {
  ArrowLeft,
  BookOpen,
  Bot,
  Search,
  Crown,
  Globe,
  Lightbulb,
  Users,
  CheckCircle,
  ArrowRight,
  Star,
  Zap,
} from "lucide-react";

export default function UserGuide() {
  const guides = [
    {
      id: "getting-started",
      title: "Bắt đầu sử dụng",
      icon: <BookOpen className="w-5 h-5" />,
      description: "Hướng dẫn cơ bản để sử dụng công cụ AEO",
      color: "bg-primary/10 border-primary/20",
      steps: [
        "Đăng ký tài khoản miễn phí",
        "Đăng nhập vào hệ thống",
        "Nhập từ kh��a và chủ đề",
        "Chọn độ dài nội dung mong muốn",
        "Nhấn 'Bắt đầu viết' để tạo nội dung",
        "Sao chép nội dung đã tạo",
      ],
    },
    {
      id: "aeo-content",
      title: "Tạo nội dung AEO",
      icon: <Bot className="w-5 h-5" />,
      description: "Cách tạo nội dung tối ưu cho AI",
      color: "bg-accent/10 border-accent/20",
      steps: [
        "Chọn từ khóa chính phù hợp với chủ đề",
        "Xác định chủ đề cụ thể và rõ ràng",
        "Đặt độ dài phù hợp (100-5000 ký tự)",
        "Kiểm tra gợi ý từ lịch sử sử dụng",
        "Đọc và chỉnh sửa nội dung nếu cần",
        "Sử dụng nội dung cho website hoặc blog",
      ],
    },
    {
      id: "keyword-research",
      title: "Nghiên cứu từ khóa",
      icon: <Search className="w-5 h-5" />,
      description: "Tìm kiếm từ khóa hiệu quả với AI",
      color: "bg-warning/10 border-warning/20",
      steps: [
        "Truy cập trang 'Ý tưởng từ khóa'",
        "Nhập từ khóa mẫu rộng",
        "Xem các gợi ý từ khóa liên quan",
        "Kiểm tra lượng tìm kiếm và độ khó",
        "Chọn từ khóa phù hợp với nội dung",
        "Sử dụng từ khóa để tạo nội dung AEO",
      ],
    },
    {
      id: "premium-features",
      title: "Tính năng Premium",
      icon: <Crown className="w-5 h-5" />,
      description: "Tận dụng tối đa gói Premium",
      color:
        "bg-gradient-to-br from-warning/10 to-primary/10 border-warning/20",
      steps: [
        "200 lượt tạo nội dung mỗi tháng",
        "Ưu tiên xử lý nhanh chóng",
        "Hỗ trợ kỹ thuật 24/7",
        "Truy cập đầy đủ công cụ phân tích",
        "Gợi ý từ khóa nâng cao",
        "Xuất nội dung không giới hạn",
      ],
    },
  ];

  const faqs = [
    {
      question: "AEO là gì và tại sao quan trọng?",
      answer:
        "AEO (AI Engine Optimization) là tối ưu hóa nội dung cho các công cụ tìm kiếm AI như ChatGPT, Bard, Claude. Khác với SEO truyền thống, AEO tập trung vào việc tạo nội dung mà AI có thể hiểu và trích xuất thông tin dễ dàng.",
    },
    {
      question: "Tôi có bao nhiêu lượt sử dụng miễn phí?",
      answer:
        "Tài khoản miễn phí được cung cấp 10 lượt tạo nội dung AEO. Sau khi h��t lượt, bạn có thể nâng cấp lên Premium để có 200 lượt mỗi tháng.",
    },
    {
      question: "Làm thế nào để nâng cấp tài khoản?",
      answer:
        "Nhấp vào nút 'Nâng cấp Premium' trong trang chủ, điền thông tin và liên hệ Zalo 0792762794 để hoàn tất thanh toán 299,000₫/tháng.",
    },
    {
      question: "Nội dung được tạo có chất lượng như thế nào?",
      answer:
        "Công cụ sử dụng AI Gemini 2.0 Flash để tạo nội dung chất lượng cao, tối ưu cho AEO. Nội dung được viết bằng tiếng Việt tự nhiên, có cấu trúc rõ ràng và phù hợp với từ khóa.",
    },
    {
      question: "Tôi có thể sử dụng nội dung cho mục đích thương mại không?",
      answer:
        "Có, bạn hoàn toàn có thể sử dụng nội dung được tạo cho website, blog, marketing hoặc bất kỳ mục đích thương mại nào.",
    },
  ];

  return (
    <div className="min-h-screen bg-background grid-bg py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary rounded-full opacity-5 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent rounded-full opacity-10 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Về trang chủ
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">
              <span className="neo-text-gradient">Hướng dẫn sử dụng</span>
            </h1>
            <p className="text-muted-foreground">
              Tìm hiểu cách sử dụng công cụ AEO một cách hiệu quả
            </p>
          </div>
        </div>

        {/* Quick Start */}
        <Card className="neo-border mb-8 bg-gradient-to-r from-primary/5 to-accent/5">
          <CardHeader>
            <CardTitle className="flex items-center text-xl">
              <Zap className="w-6 h-6 mr-2 text-primary" />
              Bắt đầu nhanh
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">1. Đăng ký</h3>
                <p className="text-sm text-muted-foreground">
                  Tạo tài khoản miễn phí trong 30 giây
                </p>
              </div>
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">2. Tạo nội dung</h3>
                <p className="text-sm text-muted-foreground">
                  Nhập từ khóa và để AI tạo nội dung AEO
                </p>
              </div>
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-warning rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">3. Sử dụng</h3>
                <p className="text-sm text-muted-foreground">
                  Copy nội dung và sử dụng cho website
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Guides */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {guides.map((guide) => (
            <Card key={guide.id} className={`neo-border ${guide.color}`}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  {guide.icon}
                  <span className="ml-2">{guide.title}</span>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  {guide.description}
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {guide.steps.map((step, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center text-xs font-bold mt-0.5">
                        {index + 1}
                      </div>
                      <p className="text-sm flex-1">{step}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <Card className="neo-border mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lightbulb className="w-5 h-5 mr-2" />
              Câu hỏi thường gặp
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {faqs.map((faq, index) => (
                <div key={index} className="space-y-2">
                  <h3 className="font-semibold text-primary">{faq.question}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                  {index < faqs.length - 1 && (
                    <hr className="border-border mt-4" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Advanced Tips */}
        <Card className="neo-border mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="w-5 h-5 mr-2" />
              Mẹo sử dụng nâng cao
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold">Tối ưu từ khóa:</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>
                      Sử dụng từ khóa dài hơn (long-tail) để có kết quả cụ thể
                      hơn
                    </span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>Kết hợp từ khóa chính với từ khóa phụ liên quan</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>Nghiên cứu từ khóa trước khi tạo nội dung</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Tối ưu nội dung:</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>Chọn độ dài phù hợp với mục đích sử dụng</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>Đọc và chỉnh sửa nội dung trước khi xuất bản</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-success mt-0.5" />
                    <span>Kết hợp nhiều nội dung để tạo bài viết dài hơn</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="neo-border bg-gradient-to-r from-primary/10 to-accent/10">
          <CardContent className="py-8">
            <div className="text-center space-y-4">
              <h2 className="text-2xl font-bold neo-text-gradient">
                Sẵn sàng tạo nội dung AEO?
              </h2>
              <p className="text-muted-foreground">
                Bắt đầu tạo nội dung tối ưu cho AI ngay bây giờ
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="neo-gradient neo-glow-hover">
                  <Link to="/">
                    <Bot className="w-4 h-4 mr-2" />
                    Tạo nội dung ngay
                  </Link>
                </Button>
                <Button asChild variant="outline" className="neo-border">
                  <Link to="/keyword-ideas">
                    <Search className="w-4 h-4 mr-2" />
                    Tìm ý tưởng từ khóa
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support Section */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">
            Cần hỗ trợ thêm? Liên hệ với chúng tôi
          </p>
          <Button asChild variant="outline" className="neo-border">
            <a
              href="https://zalo.me/0792762794"
              target="_blank"
              rel="noopener noreferrer"
            >
              Liên hệ Zalo: 0792762794
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
}
