import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  Loader2,
  Crown,
  Check,
  Zap,
  ArrowLeft,
  Star,
  CreditCard,
  CheckCircle2,
} from "lucide-react";

export default function Upgrade() {
  const { user, isAuthenticated } = useAuth();
  const [formData, setFormData] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    email: user?.email || "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // If already premium, show status
  if (user?.plan === "premium") {
    return (
      <div className="min-h-screen bg-background grid-bg flex items-center justify-center p-4">
        <Card className="w-full max-w-md neo-border neo-glow">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-warning to-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="neo-text-gradient">
              Tài khoản Premium
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Bạn đã là thành viên Premium với 200 lượt sử dụng mỗi tháng.
            </p>
            <Button asChild className="w-full neo-gradient">
              <Link to="/">Về trang chủ</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/upgrade", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("aeo_token")}`,
        },
        body: JSON.stringify({
          ...formData,
          userId: user?.id,
          plan: "premium",
        }),
      });

      const result = await response.json();

      if (result.success) {
        setSuccess(true);
      } else {
        setError(result.message || "Có lỗi xảy ra khi nâng cấp");
      }
    } catch (error) {
      setError("Lỗi kết nối. Vui lòng thử lại.");
    }

    setLoading(false);
  };

  if (success) {
    return (
      <div className="min-h-screen bg-background grid-bg flex items-center justify-center p-4">
        <Card className="w-full max-w-md neo-border neo-glow">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-success">Yêu cầu đã được gửi!</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Chúng tôi đã nhận được yêu cầu nâng cấp của bạn.
            </p>
            <div className="p-4 bg-muted/30 rounded-lg text-sm">
              <p className="font-semibold mb-2">Thông tin thanh toán:</p>
              <p>• Số tiền: 299,000 VNĐ</p>
              <p>• Liên hệ: Zalo 0792762794</p>
              <p>• Gói: Premium (200 lượt/tháng)</p>
            </div>
            <p className="text-xs text-muted-foreground">
              Vui lòng liên hệ Zalo để hoàn tất thanh toán và kích hoạt tài
              khoản Premium.
            </p>
            <Button asChild className="w-full neo-gradient">
              <Link to="/">Về trang chủ</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background grid-bg py-8">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-warning rounded-full opacity-5 blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary rounded-full opacity-10 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Về trang chủ
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">
              <span className="neo-text-gradient">Nâng cấp Premium</span>
            </h1>
            <p className="text-muted-foreground">
              Mở khóa toàn bộ sức mạnh của công cụ AEO
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Premium Features */}
          <div className="space-y-6">
            <Card className="neo-border bg-gradient-to-br from-primary/10 to-accent/10">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-warning to-primary rounded-full flex items-center justify-center">
                    <Crown className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Gói Premium</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Dành cho người dùng chuyên nghiệp
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="text-4xl font-bold neo-text-gradient mb-2">
                    299,000₫
                  </div>
                  <p className="text-sm text-muted-foreground">/ tháng</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>200 lượt tạo content AEO mỗi tháng</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>Ưu tiên xử lý nhanh chóng</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>Hỗ trợ kỹ thuật 24/7</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>Truy cập đầy đủ công cụ phân tích</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>Xuất nội dung không giới hạn</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-success" />
                    <span>Gợi ý từ khóa nâng cao</span>
                  </div>
                </div>

                {/* Comparison with Free */}
                <div className="p-4 bg-muted/30 rounded-lg">
                  <h4 className="font-semibold mb-2 text-sm">
                    So sánh với gói miễn phí:
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <p className="text-muted-foreground">Miễn phí</p>
                      <p>10 lượt/tháng</p>
                    </div>
                    <div>
                      <p className="text-primary font-semibold">Premium</p>
                      <p>200 lượt/tháng</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Testimonial */}
            <Card className="neo-border">
              <CardContent className="pt-6">
                <div className="flex items-start space-x-3">
                  <div className="flex text-warning">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
                <blockquote className="mt-3 text-sm italic">
                  "Công cụ AEO này đã giúp tôi tạo ra hàng trăm bài viết chất
                  lượng cao, tối ưu hoàn hảo cho các công cụ tìm kiếm AI. Rất
                  đáng đầu tư!"
                </blockquote>
                <cite className="text-xs text-muted-foreground mt-2 block">
                  - Nguyễn Văn A, Digital Marketer
                </cite>
              </CardContent>
            </Card>
          </div>

          {/* Upgrade Form */}
          <div>
            <Card className="neo-border neo-glow-hover">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="w-5 h-5 mr-2" />
                  Thông tin nâng cấp
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Điền thông tin để gửi yêu cầu nâng cấp Premium
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <Alert className="border-destructive">
                      <AlertDescription className="text-destructive">
                        {error}
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="name">Họ tên *</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleChange}
                      className="neo-border"
                      placeholder="Nhập họ tên đầy đủ"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Số điện thoại *</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      className="neo-border"
                      placeholder="Nhập số điện thoại"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="neo-border"
                      placeholder="Nhập địa chỉ email"
                      required
                    />
                  </div>

                  {/* Package Selection */}
                  <div className="space-y-2">
                    <Label>Gói nâng cấp</Label>
                    <div className="p-3 border border-primary rounded-lg bg-primary/5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Crown className="w-4 h-4 text-primary" />
                          <span className="font-semibold">Premium</span>
                        </div>
                        <Badge className="neo-gradient">299,000₫/tháng</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        200 lượt tạo content + tính năng nâng cao
                      </p>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full neo-gradient neo-glow-hover"
                    size="lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Đang gửi yêu cầu...
                      </>
                    ) : (
                      <>
                        <Crown className="w-5 h-5 mr-2" />
                        Gửi yêu cầu nâng cấp
                      </>
                    )}
                  </Button>

                  <div className="text-center pt-4">
                    <p className="text-xs text-muted-foreground">
                      Sau khi gửi yêu cầu, chúng tôi sẽ liên hệ với bạn qua Zalo
                      để hướng dẫn thanh toán và kích hoạt tài khoản Premium.
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card className="neo-border bg-muted/20 mt-6">
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-3 text-center">
                  Hỗ trợ thanh toán
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Liên hệ:</span>
                    <span>Zalo 0792762794</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Hỗ trợ:</span>
                    <span>24/7</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Kích hoạt:</span>
                    <span>Ngay sau thanh toán</span>
                  </div>
                </div>
                <Button
                  asChild
                  variant="outline"
                  className="w-full mt-4 neo-border"
                  size="sm"
                >
                  <a
                    href="https://zalo.me/0792762794"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Liên hệ ngay qua Zalo
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
