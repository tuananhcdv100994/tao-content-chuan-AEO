import React, { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Navigate, Link, useSearchParams } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Alert, AlertDescription } from "../components/ui/alert";
import {
  Loader2,
  Bot,
  Sparkles,
  Copy,
  Search,
  Crown,
  User,
  LogOut,
  BarChart3,
  Globe,
  BookOpen,
  Zap,
  CheckCircle2,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../components/ui/tooltip";
import { UserProfileDropdown } from "../components/UserProfileDropdown";
import { FormattedContent } from "../components/FormattedContent";

export default function Index() {
  const { user, logout, isAuthenticated } = useAuth();
  const [searchParams] = useSearchParams();
  const [keyword, setKeyword] = useState(searchParams.get("keyword") || "");
  const [topic, setTopic] = useState(searchParams.get("topic") || "");
  const [length, setLength] = useState(500);
  const [generatedContent, setGeneratedContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [keywordSuggestions, setKeywordSuggestions] = useState<string[]>([]);
  const [topicSuggestions, setTopicSuggestions] = useState<string[]>([]);

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const usagePercentage = user ? (user.usageCount / user.maxUsage) * 100 : 0;
  const remainingUsage = user ? user.maxUsage - user.usageCount : 0;

  // Load user history for suggestions
  useEffect(() => {
    const savedHistory = localStorage.getItem(`aeo_history_${user?.id}`);
    if (savedHistory) {
      const history = JSON.parse(savedHistory);
      setKeywordSuggestions(history.keywords || []);
      setTopicSuggestions(history.topics || []);
    }
  }, [user?.id]);

  const saveToHistory = (newKeyword: string, newTopic: string) => {
    const historyKey = `aeo_history_${user?.id}`;
    const savedHistory = localStorage.getItem(historyKey);
    const history = savedHistory
      ? JSON.parse(savedHistory)
      : { keywords: [], topics: [] };

    // Add new keyword and topic, avoid duplicates
    if (newKeyword && !history.keywords.includes(newKeyword)) {
      history.keywords.unshift(newKeyword);
      history.keywords = history.keywords.slice(0, 10); // Keep only last 10
    }

    if (newTopic && !history.topics.includes(newTopic)) {
      history.topics.unshift(newTopic);
      history.topics = history.topics.slice(0, 10); // Keep only last 10
    }

    localStorage.setItem(historyKey, JSON.stringify(history));
    setKeywordSuggestions(history.keywords);
    setTopicSuggestions(history.topics);
  };

  const handleGenerate = async () => {
    if (!keyword.trim() || !topic.trim()) {
      setError("Vui lòng nhập đầy đủ từ khóa và chủ đề");
      return;
    }

    if (length < 100 || length > 5000) {
      setError("Độ dài nội dung phải từ 100 đến 5000 ký tự");
      return;
    }

    if (remainingUsage <= 0) {
      setError("Bạn đã hết lượt sử dụng. Vui lòng nâng cấp tài khoản.");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");

    try {
      const response = await fetch("/api/generate-content", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("aeo_token")}`,
        },
        body: JSON.stringify({
          keyword: keyword.trim(),
          topic: topic.trim(),
          length,
          userId: user?.id,
        }),
      });

      const result = await response.json();

      if (result.success) {
        setGeneratedContent(result.content);
        setSuccess("Nội dung AEO đã được tạo thành công!");
        saveToHistory(keyword.trim(), topic.trim());

        // Update user usage in local storage
        if (user && result.remainingUsage !== undefined) {
          const updatedUser = {
            ...user,
            usageCount: user.maxUsage - result.remainingUsage,
          };
          localStorage.setItem("aeo_user", JSON.stringify(updatedUser));
        }
      } else {
        setError(result.message || "Có lỗi xảy ra khi tạo nội dung");
      }
    } catch (error) {
      setError("Lỗi kết nối. Vui lòng thử lại.");
    }

    setLoading(false);
  };

  const handleCopyContent = async () => {
    try {
      await navigator.clipboard.writeText(generatedContent);
      setSuccess("Đã sao chép nội dung vào clipboard!");
      setTimeout(() => setSuccess(""), 3000);
    } catch (error) {
      setError("Không thể sao chép. Vui lòng chọn và copy thủ công.");
    }
  };

  return (
    <div className="min-h-screen bg-background grid-bg">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Bot className="w-8 h-8 text-primary" />
                <Sparkles className="w-4 h-4 text-accent absolute -top-1 -right-1" />
              </div>
              <div>
                <h1 className="text-xl font-bold neo-text-gradient">
                  Tạo content chuẩn AEO
                </h1>
                <p className="text-xs text-muted-foreground">by Plugai.top</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Usage indicator */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <Zap className="w-4 h-4 text-accent" />
                        <span className="text-sm font-medium">
                          {remainingUsage}/{user?.maxUsage}
                        </span>
                        {user?.plan === "premium" && (
                          <Crown className="w-4 h-4 text-warning" />
                        )}
                      </div>
                      <Progress value={usagePercentage} className="w-20 h-2" />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Còn lại {remainingUsage} lượt sử dụng</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {/* User menu */}
              <UserProfileDropdown />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content Generation */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="neo-border neo-glow-hover">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="w-5 h-5 mr-2 text-primary" />
                  Tạo nội dung AEO với AI
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {(error || success) && (
                  <Alert
                    className={error ? "border-destructive" : "border-success"}
                  >
                    <AlertDescription
                      className={error ? "text-destructive" : "text-success"}
                    >
                      {error || success}
                    </AlertDescription>
                  </Alert>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="keyword">Từ khóa chính *</Label>
                    <Input
                      id="keyword"
                      value={keyword}
                      onChange={(e) => setKeyword(e.target.value)}
                      placeholder="VD: tối ưu hóa SEO"
                      className="neo-border"
                      list="keyword-suggestions"
                    />
                    <datalist id="keyword-suggestions">
                      {keywordSuggestions.map((suggestion, index) => (
                        <option key={index} value={suggestion} />
                      ))}
                    </datalist>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="topic">Chủ đề *</Label>
                    <Input
                      id="topic"
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      placeholder="VD: Marketing Online"
                      className="neo-border"
                      list="topic-suggestions"
                    />
                    <datalist id="topic-suggestions">
                      {topicSuggestions.map((suggestion, index) => (
                        <option key={index} value={suggestion} />
                      ))}
                    </datalist>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="length">
                    Độ dài nội dung: {length} ký tự
                  </Label>
                  <input
                    type="range"
                    id="length"
                    min="100"
                    max="5000"
                    step="50"
                    value={length}
                    onChange={(e) => setLength(Number(e.target.value))}
                    className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>100</span>
                    <span>2500</span>
                    <span>5000</span>
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={loading || remainingUsage <= 0}
                  className="w-full neo-gradient neo-glow-hover"
                  size="lg"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Đang tạo nội dung AEO...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Bắt đầu viết
                    </>
                  )}
                </Button>

                {generatedContent && (
                  <FormattedContent
                    content={generatedContent}
                    onCopy={handleCopyContent}
                  />
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Account Status */}
            <Card className="neo-border">
              <CardHeader>
                <CardTitle className="flex items-center text-sm">
                  <User className="w-4 h-4 mr-2" />
                  Thông tin tài khoản
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Gói:</span>
                    <Badge
                      variant={
                        user?.plan === "premium" ? "default" : "secondary"
                      }
                      className={user?.plan === "premium" ? "neo-gradient" : ""}
                    >
                      {user?.plan === "premium" ? (
                        <>
                          <Crown className="w-3 h-3 mr-1" />
                          Premium
                        </>
                      ) : (
                        "Miễn phí"
                      )}
                    </Badge>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Đã sử dụng:</span>
                      <span>
                        {user?.usageCount}/{user?.maxUsage}
                      </span>
                    </div>
                    <Progress value={usagePercentage} className="h-2" />
                  </div>
                </div>

                {user?.plan === "free" && (
                  <Button asChild className="w-full neo-gradient" size="sm">
                    <Link to="/upgrade">
                      <Crown className="w-4 h-4 mr-2" />
                      Nâng cấp Premium
                    </Link>
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Additional Tools */}
            <Card className="neo-border">
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Công cụ hỗ trợ
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  asChild
                  variant="outline"
                  className="w-full justify-start neo-border"
                  size="sm"
                >
                  <Link to="/keyword-ideas">
                    <Search className="w-4 h-4 mr-2" />Ý tưởng từ khóa
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  className="w-full justify-start neo-border"
                  size="sm"
                >
                  <Link to="/website-analysis">
                    <Globe className="w-4 h-4 mr-2" />
                    Phân tích website
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  className="w-full justify-start neo-border"
                  size="sm"
                >
                  <Link to="/guide">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Hướng dẫn sử dụng
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Contact Support */}
            <Card className="neo-border bg-primary/5">
              <CardContent className="pt-6">
                <div className="text-center space-y-2">
                  <h3 className="font-semibold text-sm">Cần hỗ trợ?</h3>
                  <p className="text-xs text-muted-foreground">
                    Liên hệ với chúng tôi qua Zalo
                  </p>
                  <Button
                    asChild
                    variant="outline"
                    size="sm"
                    className="neo-border"
                  >
                    <a
                      href="https://zalo.me/0792762794"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Zalo: 0792762794
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
