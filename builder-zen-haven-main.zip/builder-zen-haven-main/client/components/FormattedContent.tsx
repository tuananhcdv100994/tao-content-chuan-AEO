import React from "react";
import { Button } from "./ui/button";
import { Copy, Download, FileText } from "lucide-react";

interface FormattedContentProps {
  content: string;
  onCopy: () => void;
}

export const FormattedContent: React.FC<FormattedContentProps> = ({
  content,
  onCopy,
}) => {
  // Simple markdown parser for basic formatting
  const parseMarkdown = (text: string) => {
    return (
      text
        // Headers
        .replace(
          /^### (.+)$/gm,
          '<h3 class="text-lg font-semibold text-primary mt-6 mb-3 flex items-center"><span class="w-2 h-2 bg-accent rounded-full mr-2"></span>$1</h3>',
        )
        .replace(
          /^## (.+)$/gm,
          '<h2 class="text-xl font-bold text-foreground mt-8 mb-4 flex items-center"><span class="w-3 h-3 bg-primary rounded-full mr-2"></span>$1</h2>',
        )
        .replace(
          /^# (.+)$/gm,
          '<h1 class="text-2xl font-bold text-primary mb-6 pb-3 border-b border-border flex items-center"><span class="w-4 h-4 bg-gradient-to-r from-primary to-accent rounded-full mr-3"></span>$1</h1>',
        )

        // Bold text
        .replace(
          /\*\*(.+?)\*\*/g,
          '<strong class="font-semibold text-foreground">$1</strong>',
        )

        // Italic text
        .replace(
          /\*(.+?)\*/g,
          '<em class="italic text-muted-foreground">$1</em>',
        )

        // Lists
        .replace(
          /^- (.+)$/gm,
          '<li class="flex items-start space-x-2 mb-2"><span class="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0"></span><span>$1</span></li>',
        )

        // Line breaks
        .replace(/\n\n/g, '</p><p class="mb-4">')
        .replace(/\n/g, "<br/>")
    );
  };

  const formatContent = (text: string) => {
    // Wrap content in paragraphs and parse markdown
    const formatted = parseMarkdown(text);

    // Wrap in paragraph tags if not already structured
    const withParagraphs =
      formatted.includes("<h1>") || formatted.includes("<h2>")
        ? formatted
        : `<p class="mb-4">${formatted}</p>`;

    return withParagraphs;
  };

  const downloadAsFile = () => {
    const element = document.createElement("a");
    const file = new Blob([content], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "aeo-content.txt";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-4">
      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileText className="w-5 h-5 text-primary" />
          <span className="text-lg font-semibold">Nội dung AEO đã tạo</span>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={downloadAsFile}
            variant="outline"
            size="sm"
            className="neo-border"
          >
            <Download className="w-4 h-4 mr-2" />
            Tải xuống
          </Button>
          <Button
            onClick={onCopy}
            variant="outline"
            size="sm"
            className="neo-border"
          >
            <Copy className="w-4 h-4 mr-2" />
            Sao chép
          </Button>
        </div>
      </div>

      {/* Formatted Content Display */}
      <div className="neo-border rounded-lg p-6 bg-card/50 backdrop-blur-sm">
        <div
          className="prose prose-invert max-w-none"
          dangerouslySetInnerHTML={{
            __html: formatContent(content),
          }}
          style={{
            lineHeight: "1.7",
            fontSize: "15px",
          }}
        />
      </div>

      {/* Content Stats */}
      <div className="grid grid-cols-3 gap-4 text-center">
        <div className="p-3 bg-muted/20 rounded-lg">
          <div className="text-lg font-bold text-primary">
            {content.length.toLocaleString()}
          </div>
          <div className="text-xs text-muted-foreground">Ký tự</div>
        </div>
        <div className="p-3 bg-muted/20 rounded-lg">
          <div className="text-lg font-bold text-accent">
            {content.split(/\s+/).length.toLocaleString()}
          </div>
          <div className="text-xs text-muted-foreground">Từ</div>
        </div>
        <div className="p-3 bg-muted/20 rounded-lg">
          <div className="text-lg font-bold text-warning">
            {content.split(/[.!?]+/).length - 1}
          </div>
          <div className="text-xs text-muted-foreground">Câu</div>
        </div>
      </div>

      {/* AEO Optimization Tips */}
      <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <h4 className="font-semibold text-primary mb-2 flex items-center">
          <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
          Mẹo tối ưu AEO
        </h4>
        <div className="text-sm text-muted-foreground space-y-1">
          <p>✅ Nội dung đã được cấu trúc với tiêu đề rõ ràng</p>
          <p>✅ Sử dụng từ khóa tự nhiên trong ngữ cảnh</p>
          <p>✅ Thông tin được sắp xếp logic, dễ hiểu cho AI</p>
          <p>💡 Có thể chỉnh sửa và bổ sung thêm thông tin nếu cần</p>
        </div>
      </div>
    </div>
  );
};
